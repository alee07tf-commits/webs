// Icons
lucide.createIcons();

// Navbar Scroll Effect
const navbar = document.getElementById('navbar');
let lastScroll = 0;

window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;
    
    if (currentScroll > 50) {
        if (currentScroll > lastScroll) {
            // Scrolling Down
            navbar.style.transform = 'translateY(-100%)';
        } else {
            // Scrolling Up
            navbar.style.transform = 'translateY(0)';
        }
    }
    lastScroll = currentScroll;
});

// Intersection Observer for Animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            // Optional: Stop observing once visible to run only once
            observer.unobserve(entry.target);
            
            // Count Up Animation trigger
            const counters = entry.target.querySelectorAll('.count-up');
            counters.forEach(counter => {
                const target = +counter.getAttribute('data-target');
                let count = 0;
                const inc = target / 40; // speed
                
                const updateCount = () => {
                    count += inc;
                    if (count < target) {
                        counter.innerText = Math.ceil(count);
                        requestAnimationFrame(updateCount);
                    } else {
                        counter.innerText = target;
                    }
                };
                updateCount();
            });
        }
    });
}, observerOptions);

document.querySelectorAll('.anim-fade-up, .anim-stagger, .anim-slide-right, .anim-scale').forEach(el => {
    observer.observe(el);
});

// Accordion Logic
function toggleAccordion(button) {
    const content = button.nextElementSibling;
    const icon = button.querySelector('i');
    
    content.classList.toggle('open');
    if (content.classList.contains('open')) {
        icon.style.transform = 'rotate(45deg)';
        icon.style.color = '#3B82F6'; // Primary color
    } else {
        icon.style.transform = 'rotate(0deg)';
        icon.style.color = '#94A3B8'; // Secondary color
    }
}
